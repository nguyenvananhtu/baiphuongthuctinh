package basic.dev;

import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
			int a,b;
			System.out.println("Nhap a:");
			a = sc.nextInt();
			System.out.println("Nhap b:");
			b = sc.nextInt();
			int t = tong(a,b);
			System.out.println(t);
			int h = hieu(a,b);
			System.out.println(h);
			int n = tich(a,b);
			System.out.println(n);
			int c = thuong(a,b);
			System.out.println(c);
				
	}
	static int tong(int a,int b) {
		return a + b ;
	}
	static int hieu(int a,int b) {
		return a - b ;
	}
	static int tich(int a,int b) {
		return a * b ;
	}
	static int thuong(int a,int b) {
		return a / b ;
	}
}
