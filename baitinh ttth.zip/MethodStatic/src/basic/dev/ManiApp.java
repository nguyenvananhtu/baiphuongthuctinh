package basic.dev;

public class ManiApp {

	
	}
	
}
